﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tema1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comboBox_experience.Items.AddRange(new string[]
            {
        "First-time cat adopter",
        "Had a cat as a child",
        "Currently have a cat",
        "Previously adopted cats",
        "Volunteered at a shelter"
            });

            comboBox_living.Items.AddRange(new string[]
            {
        "Apartment",
        "House with yard",
        "Shared space / roommate",
        "Student dorm",
        "Living with parents",
        "Other"
            });
        }


        private void label6_Click(object sender, EventArgs e)
        {

        }

        
           private void Submit_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                string.IsNullOrWhiteSpace(textBox_city.Text) ||
                comboBox_experience.SelectedIndex == -1 ||
                comboBox_living.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(textBox_phone.Text) ||
                string.IsNullOrWhiteSpace(textBox_mail.Text))
            {
                MessageBox.Show("Please fill in all required fields.");
                return;
            }

            
            if (!textBox_phone.Text.All(char.IsDigit))
            {
                MessageBox.Show("Phone number should contain digits only.");
                return;
            }

            string email = textBox_mail.Text;
            if (!email.Contains("@") || !email.EndsWith(".com"))
            {
                MessageBox.Show("Please enter a valid email address (example@example.com).");
                return;
            }

           
            Form4 form4 = new Form4();
            form4.Show();
            this.Close();
        }
        



        private void textBox_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_city_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_experience_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_living_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_dog_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_otherCats_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_birds_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_none_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox_other_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox_other_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_mail_TextChanged(object sender, EventArgs e)
        {

        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Close();
        }
    }
}
