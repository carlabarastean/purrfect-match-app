﻿namespace Tema1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            searchName = new TextBox();
            searchGender = new ComboBox();
            label3 = new Label();
            checkBox_calm = new CheckBox();
            checkBox_kittens = new CheckBox();
            ApplyFilters_button = new Button();
            panel1 = new Panel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            button_back = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 24);
            label1.Name = "label1";
            label1.Size = new Size(504, 51);
            label1.TabIndex = 0;
            label1.Text = "Meet Your Purrfect Match";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(7, 28);
            label2.Name = "label2";
            label2.Size = new Size(210, 37);
            label2.TabIndex = 1;
            label2.Text = "Search by name:";
            // 
            // searchName
            // 
            searchName.BackColor = Color.Honeydew;
            searchName.Location = new Point(223, 29);
            searchName.Name = "searchName";
            searchName.Size = new Size(229, 39);
            searchName.TabIndex = 2;
            searchName.TextChanged += searchName_TextChanged;
            // 
            // searchGender
            // 
            searchGender.BackColor = Color.Honeydew;
            searchGender.FormattingEnabled = true;
            searchGender.Location = new Point(619, 25);
            searchGender.Name = "searchGender";
            searchGender.Size = new Size(242, 40);
            searchGender.TabIndex = 3;
            searchGender.SelectedIndexChanged += searchGender_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.125F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(503, 28);
            label3.Name = "label3";
            label3.Size = new Size(110, 37);
            label3.TabIndex = 4;
            label3.Text = "Gender:";
            // 
            // checkBox_calm
            // 
            checkBox_calm.AutoSize = true;
            checkBox_calm.Location = new Point(16, 90);
            checkBox_calm.Name = "checkBox_calm";
            checkBox_calm.Size = new Size(201, 36);
            checkBox_calm.TabIndex = 5;
            checkBox_calm.Text = "Calm cats only";
            checkBox_calm.UseVisualStyleBackColor = true;
            checkBox_calm.CheckedChanged += checkBox_calm_CheckedChanged;
            // 
            // checkBox_kittens
            // 
            checkBox_kittens.AutoSize = true;
            checkBox_kittens.Location = new Point(16, 142);
            checkBox_kittens.Name = "checkBox_kittens";
            checkBox_kittens.Size = new Size(174, 36);
            checkBox_kittens.TabIndex = 6;
            checkBox_kittens.Text = "Only kittens";
            checkBox_kittens.UseVisualStyleBackColor = true;
            checkBox_kittens.CheckedChanged += checkBox_kittens_CheckedChanged;
            // 
            // ApplyFilters_button
            // 
            ApplyFilters_button.BackColor = Color.LightGreen;
            ApplyFilters_button.Location = new Point(1121, 28);
            ApplyFilters_button.Name = "ApplyFilters_button";
            ApplyFilters_button.Size = new Size(217, 54);
            ApplyFilters_button.TabIndex = 7;
            ApplyFilters_button.Text = "Apply filters";
            ApplyFilters_button.UseVisualStyleBackColor = false;
            ApplyFilters_button.Click += ApplyFilters_button_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.PeachPuff;
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(ApplyFilters_button);
            panel1.Controls.Add(checkBox_kittens);
            panel1.Controls.Add(checkBox_calm);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(searchGender);
            panel1.Controls.Add(searchName);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(18, 68);
            panel1.Name = "panel1";
            panel1.Size = new Size(1357, 203);
            panel1.TabIndex = 8;
            panel1.Paint += panel1_Paint;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoScroll = true;
            flowLayoutPanel1.Location = new Point(18, 291);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1357, 751);
            flowLayoutPanel1.TabIndex = 9;
            // 
            // button_back
            // 
            button_back.BackColor = Color.LightSalmon;
            button_back.Location = new Point(21, 1135);
            button_back.Name = "button_back";
            button_back.Size = new Size(202, 40);
            button_back.TabIndex = 10;
            button_back.Text = "Back";
            button_back.UseVisualStyleBackColor = false;
            button_back.Click += button_back_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(1400, 1200);
            Controls.Add(button_back);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "Form3";
            Text = "AdoptMe";
            Load += Form3_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox searchName;
        private ComboBox searchGender;
        private Label label3;
        private CheckBox checkBox_calm;
        private CheckBox checkBox_kittens;
        private Button ApplyFilters_button;
        private Panel panel1;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button button_back;
    }
}