﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Tema1
{
    public partial class Form3 : Form
    {
        List<Cat> allCats = new List<Cat>();

        public Form3()
        {
            InitializeComponent();


            searchGender.Items.AddRange(new string[] { "All", "Male", "Female" });
            searchGender.SelectedIndex = 0;


            this.Load += new EventHandler(Form3_Load);
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            allCats = new List<Cat>
            {
                new Cat
                {
                    Name = "Tiger",
                    Age = 2,
                    Gender = "Male",
                    Personality = "Tiger is a confident explorer who loves lounging in sunny spots and watching the world from the window.",
                    IsCalm = true,
                    Image = Properties.Resources._1
                },
                new Cat
                {
                    Name = "Whiskers",
                    Age = 0,
                    Gender = "Male",
                    Personality = "Whiskers is a playful kitten who loves chasing toys, climbing furniture, and following you everywhere.",
                    IsCalm = false,
                    Image = Properties.Resources._3
                },
                new Cat
                {
                    Name = "Oreo",
                    Age = 1,
                    Gender = "Male",
                    Personality = "Oreo may be quiet at first, but once he warms up, he's all cuddles and soft purrs.",
                    IsCalm = true,
                    Image = Properties.Resources._4
                },
                new Cat
                {
                    Name = "Muffin",
                    Age = 1,
                    Gender = "Female",
                    Personality = "Muffin is a chill queen who loves soft blankets, warm naps, and gentle company.",
                    IsCalm = false,
                    Image = Properties.Resources._5
                }
            };

            LoadCats(allCats);
        }

        private void LoadCats(List<Cat> cats)
        {
            flowLayoutPanel1.Controls.Clear();

            if (cats.Count == 0)
            {
                MessageBox.Show("No cats found with the selected filters.");
                return;
            }

            foreach (var cat in cats)
            {
                var card = CreateCatCard(cat);
                flowLayoutPanel1.Controls.Add(card);
            }
        }

        private GroupBox CreateCatCard(Cat cat)
        {
            GroupBox groupBox = new GroupBox();
            groupBox.Width = 300;
            groupBox.Height = 550;
            groupBox.Text = cat.Name;
            groupBox.Font = new Font("Segoe UI", 9, FontStyle.Bold);

            PictureBox pic = new PictureBox();
            pic.Image = cat.Image;
            pic.SizeMode = PictureBoxSizeMode.StretchImage;
            pic.Width = 260;
            pic.Height = 160;
            pic.Top = 30;
            pic.Left = 15;

            Label info = new Label();
            info.Text = $"Age: {cat.Age}\nGender: {cat.Gender}";
            info.Top = pic.Bottom + 30;
            info.Left = 15;
            info.Width = 260;
            info.Height = 80;

            Label personality = new Label();
            personality.Text = cat.Personality;
            personality.Top = info.Bottom + 30;
            personality.Left = 15;
            personality.Width = 260;
            personality.Height = 120;
            personality.Font = new Font("Segoe UI", 8, FontStyle.Italic);
            personality.AutoSize = false;

            Button choose = new Button();
            choose.Text = "Choose Me!";
            choose.BackColor = Color.LightPink;
            choose.Top = personality.Bottom + 30;
            choose.Left = 15;
            choose.Width = 260;
            choose.Height = 40;
            choose.Click += (s, e) =>
            {
                Form2 form2 = new Form2();
                form2.Show();
                this.Close();
            };

            groupBox.Controls.Add(pic);
            groupBox.Controls.Add(info);
            groupBox.Controls.Add(personality);
            groupBox.Controls.Add(choose);

            return groupBox;
        }



        private void ApplyFilters_button_Click(object sender, EventArgs e)
        {
            string nameFilter = searchName.Text.ToLower();
            string genderFilter = searchGender.SelectedItem?.ToString();
            bool calmOnly = checkBox_calm.Checked;
            bool kittensOnly = checkBox_kittens.Checked;

            var filteredCats = allCats.Where(cat =>
                (string.IsNullOrEmpty(nameFilter) || cat.Name.ToLower().Contains(nameFilter)) &&
                (string.IsNullOrEmpty(genderFilter) || genderFilter == "All" || cat.Gender == genderFilter) &&
                (!calmOnly || cat.IsCalm) &&
                (!kittensOnly || cat.IsKitten)
            ).ToList();

            LoadCats(filteredCats);
        }

        private void button_back_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }


        private void textBox2_TextChanged(object sender, EventArgs e) { }
        private void searchName_TextChanged(object sender, EventArgs e) { }
        private void searchGender_SelectedIndexChanged(object sender, EventArgs e) { }
        private void checkBox_calm_CheckedChanged(object sender, EventArgs e) { }
        private void checkBox_kittens_CheckedChanged(object sender, EventArgs e) { }
     

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }

    public class Cat
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Personality { get; set; }
        public Image Image { get; set; }
        public bool IsCalm { get; set; }
        public bool IsKitten => Age < 1;
    }
}
