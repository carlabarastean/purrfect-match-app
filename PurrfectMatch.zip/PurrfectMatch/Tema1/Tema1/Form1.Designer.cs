﻿namespace Tema1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            label2 = new Label();
            catImage = new PictureBox();
            startButton = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)catImage).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(317, 211);
            label1.Name = "label1";
            label1.Size = new Size(744, 74);
            label1.TabIndex = 0;
            label1.Text = "Welcome to PurrfectMatch!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(435, 312);
            label2.Name = "label2";
            label2.Size = new Size(495, 45);
            label2.TabIndex = 1;
            label2.Text = "Let's find your feline soulmate <3";
            // 
            // catImage
            // 
            catImage.Image = (Image)resources.GetObject("catImage.Image");
            catImage.Location = new Point(-3, 391);
            catImage.Name = "catImage";
            catImage.Size = new Size(1016, 574);
            catImage.SizeMode = PictureBoxSizeMode.CenterImage;
            catImage.TabIndex = 2;
            catImage.TabStop = false;
            // 
            // startButton
            // 
            startButton.BackColor = Color.LightSkyBlue;
            startButton.Font = new Font("Segoe UI Black", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            startButton.Location = new Point(1063, 695);
            startButton.Name = "startButton";
            startButton.Size = new Size(299, 107);
            startButton.TabIndex = 3;
            startButton.Text = "Start your Journey";
            startButton.UseVisualStyleBackColor = false;
            startButton.Click += startButton_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.arrow;
            pictureBox1.Location = new Point(1063, 470);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(261, 219);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(1385, 826);
            Controls.Add(pictureBox1);
            Controls.Add(startButton);
            Controls.Add(catImage);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "PurrfectMatch";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)catImage).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private PictureBox catImage;
        private Button startButton;
        private PictureBox pictureBox1;
    }
}
