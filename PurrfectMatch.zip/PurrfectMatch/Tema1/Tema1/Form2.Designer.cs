﻿namespace Tema1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            backButton = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label6 = new Label();
            textBox_name = new TextBox();
            textBox_city = new TextBox();
            comboBox_experience = new ComboBox();
            comboBox_living = new ComboBox();
            label5 = new Label();
            label7 = new Label();
            checkBox_dog = new CheckBox();
            checkBox_otherCats = new CheckBox();
            checkBox_birds = new CheckBox();
            checkBox_none = new CheckBox();
            checkBox_other = new CheckBox();
            textBox_other = new TextBox();
            label8 = new Label();
            label9 = new Label();
            textBox_phone = new TextBox();
            textBox_mail = new TextBox();
            Submit_button = new Button();
            SuspendLayout();
            // 
            // backButton
            // 
            backButton.BackColor = Color.LightCyan;
            backButton.Location = new Point(681, 645);
            backButton.Name = "backButton";
            backButton.Size = new Size(278, 64);
            backButton.TabIndex = 0;
            backButton.Text = "Back";
            backButton.UseVisualStyleBackColor = false;
            backButton.Click += backButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(42, 36);
            label1.Name = "label1";
            label1.Size = new Size(446, 45);
            label1.TabIndex = 1;
            label1.Text = "Let's get to know you better!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(42, 116);
            label2.Name = "label2";
            label2.Size = new Size(168, 34);
            label2.TabIndex = 2;
            label2.Text = "Your Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(42, 175);
            label3.Name = "label3";
            label3.Size = new Size(143, 34);
            label3.TabIndex = 3;
            label3.Text = "Your City:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(42, 245);
            label4.Name = "label4";
            label4.Size = new Size(300, 34);
            label4.TabIndex = 4;
            label4.Text = "Experience with Cats:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(42, 387);
            label6.Name = "label6";
            label6.Size = new Size(0, 34);
            label6.TabIndex = 6;
            label6.Click += label6_Click;
            // 
            // textBox_name
            // 
            textBox_name.Location = new Point(363, 111);
            textBox_name.Name = "textBox_name";
            textBox_name.Size = new Size(364, 39);
            textBox_name.TabIndex = 7;
            textBox_name.TextChanged += textBox_name_TextChanged;
            // 
            // textBox_city
            // 
            textBox_city.Location = new Point(363, 170);
            textBox_city.Name = "textBox_city";
            textBox_city.Size = new Size(364, 39);
            textBox_city.TabIndex = 8;
            textBox_city.TextChanged += textBox_city_TextChanged;
            // 
            // comboBox_experience
            // 
            comboBox_experience.FormattingEnabled = true;
            comboBox_experience.Location = new Point(363, 239);
            comboBox_experience.Name = "comboBox_experience";
            comboBox_experience.Size = new Size(364, 40);
            comboBox_experience.TabIndex = 9;
            comboBox_experience.SelectedIndexChanged += comboBox_experience_SelectedIndexChanged;
            // 
            // comboBox_living
            // 
            comboBox_living.FormattingEnabled = true;
            comboBox_living.Location = new Point(363, 318);
            comboBox_living.Name = "comboBox_living";
            comboBox_living.Size = new Size(364, 40);
            comboBox_living.TabIndex = 11;
            comboBox_living.SelectedIndexChanged += comboBox_living_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(42, 324);
            label5.Name = "label5";
            label5.Size = new Size(233, 34);
            label5.TabIndex = 12;
            label5.Text = "Living Situation:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(42, 405);
            label7.Name = "label7";
            label7.Size = new Size(279, 34);
            label7.TabIndex = 13;
            label7.Text = "Other Pets at Home:";
            // 
            // checkBox_dog
            // 
            checkBox_dog.AutoSize = true;
            checkBox_dog.Location = new Point(363, 405);
            checkBox_dog.Name = "checkBox_dog";
            checkBox_dog.Size = new Size(101, 36);
            checkBox_dog.TabIndex = 14;
            checkBox_dog.Text = "Dogs";
            checkBox_dog.UseVisualStyleBackColor = true;
            checkBox_dog.CheckedChanged += checkBox_dog_CheckedChanged;
            // 
            // checkBox_otherCats
            // 
            checkBox_otherCats.AutoSize = true;
            checkBox_otherCats.Location = new Point(470, 405);
            checkBox_otherCats.Name = "checkBox_otherCats";
            checkBox_otherCats.Size = new Size(155, 36);
            checkBox_otherCats.TabIndex = 15;
            checkBox_otherCats.Text = "Other cats";
            checkBox_otherCats.UseVisualStyleBackColor = true;
            checkBox_otherCats.CheckedChanged += checkBox_otherCats_CheckedChanged;
            // 
            // checkBox_birds
            // 
            checkBox_birds.AutoSize = true;
            checkBox_birds.Location = new Point(641, 405);
            checkBox_birds.Name = "checkBox_birds";
            checkBox_birds.Size = new Size(98, 36);
            checkBox_birds.TabIndex = 16;
            checkBox_birds.Text = "Birds";
            checkBox_birds.UseVisualStyleBackColor = true;
            checkBox_birds.CheckedChanged += checkBox_birds_CheckedChanged;
            // 
            // checkBox_none
            // 
            checkBox_none.AutoSize = true;
            checkBox_none.Location = new Point(745, 405);
            checkBox_none.Name = "checkBox_none";
            checkBox_none.Size = new Size(105, 36);
            checkBox_none.TabIndex = 17;
            checkBox_none.Text = "None";
            checkBox_none.UseVisualStyleBackColor = true;
            checkBox_none.CheckedChanged += checkBox_none_CheckedChanged;
            // 
            // checkBox_other
            // 
            checkBox_other.AutoSize = true;
            checkBox_other.Location = new Point(878, 405);
            checkBox_other.Name = "checkBox_other";
            checkBox_other.Size = new Size(112, 36);
            checkBox_other.TabIndex = 18;
            checkBox_other.Text = "Other:";
            checkBox_other.UseVisualStyleBackColor = true;
            checkBox_other.CheckedChanged += checkBox_other_CheckedChanged;
            // 
            // textBox_other
            // 
            textBox_other.Location = new Point(996, 399);
            textBox_other.Name = "textBox_other";
            textBox_other.Size = new Size(256, 39);
            textBox_other.TabIndex = 19;
            textBox_other.TextChanged += textBox_other_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(42, 480);
            label8.Name = "label8";
            label8.Size = new Size(220, 34);
            label8.TabIndex = 20;
            label8.Text = "Phone number:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Cambria", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(42, 546);
            label9.Name = "label9";
            label9.Size = new Size(100, 34);
            label9.TabIndex = 21;
            label9.Text = "Email:";
            // 
            // textBox_phone
            // 
            textBox_phone.Location = new Point(363, 475);
            textBox_phone.Name = "textBox_phone";
            textBox_phone.Size = new Size(364, 39);
            textBox_phone.TabIndex = 22;
            textBox_phone.TextChanged += textBox_phone_TextChanged;
            // 
            // textBox_mail
            // 
            textBox_mail.Location = new Point(363, 541);
            textBox_mail.Name = "textBox_mail";
            textBox_mail.Size = new Size(364, 39);
            textBox_mail.TabIndex = 23;
            textBox_mail.TextChanged += textBox_mail_TextChanged;
            // 
            // Submit_button
            // 
            Submit_button.BackColor = Color.Thistle;
            Submit_button.Location = new Point(1011, 645);
            Submit_button.Name = "Submit_button";
            Submit_button.Size = new Size(288, 64);
            Submit_button.TabIndex = 24;
            Submit_button.Text = "Submit";
            Submit_button.UseVisualStyleBackColor = false;
            Submit_button.Click += Submit_button_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(1369, 811);
            Controls.Add(Submit_button);
            Controls.Add(textBox_mail);
            Controls.Add(textBox_phone);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(textBox_other);
            Controls.Add(checkBox_other);
            Controls.Add(checkBox_none);
            Controls.Add(checkBox_birds);
            Controls.Add(checkBox_otherCats);
            Controls.Add(checkBox_dog);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(comboBox_living);
            Controls.Add(comboBox_experience);
            Controls.Add(textBox_city);
            Controls.Add(textBox_name);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(backButton);
            Name = "Form2";
            Text = "Nice2MeetYou";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button backButton;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label6;
        private TextBox textBox_name;
        private TextBox textBox_city;
        private ComboBox comboBox_experience;
        private ComboBox comboBox_living;
        private Label label5;
        private Label label7;
        private CheckBox checkBox_dog;
        private CheckBox checkBox_otherCats;
        private CheckBox checkBox_birds;
        private CheckBox checkBox_none;
        private CheckBox checkBox_other;
        private TextBox textBox_other;
        private Label label8;
        private Label label9;
        private TextBox textBox_phone;
        private TextBox textBox_mail;
        private Button Submit_button;
    }
}